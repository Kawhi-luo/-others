/**
 * Created by lily.shen on 2/1/18.
 */
var async = require("async");
var strftime = require("strftime");
const RadarClient = require("@marcom/node-radar");
var radarClient = new RadarClient();

const runTask = (options,auth,cb) => {

    function getLocalTime() {
        // Create a new Date instance, representing the current instant in time
        var currTime = strftime("%Y-%m-%d %H:%M:%S");
        currTime = currTime.replace(" ", "T") + "+0000";
        return currTime;
    }
    let opt = JSON.parse(options);
    let suiteID=opt['suiteId'];
    let stTitle=opt['stTitle'];

    radarClient.authenticateSpnego(function (err, rc) {
    if(err){
        console.log("Login Failed");
    }else{
        async.mapSeries(stTitle, (item, callback) => {
            createScheduledTest(radarClient, item, callback);
        }, (results) => {
           cb(results);
        })}

    function createScheduledTest(radarClient, item,  callback){
        var stData = {
            "suiteID": suiteID
        };
        radarClient.makeScheduledTest(stData, function(err, scheduledTest){
            if (err){
                console.log("err", stData);

            } else {
                var updateStData={
                    "scheduledStartDate": getLocalTime(),
                    "scheduledEndDate":getLocalTime(),
                    "title":scheduledTest.title+" - "+item,
                    "geography":item.split(' ')[0]
                }
                scheduledTest.update(updateStData, function(err1, updateScheduledTest){
                    if (err1){
                        console.log(err1);
                    }else{
                        callback(null, scheduledTest);
                    }
                })

            }
        });
    }
    })
    radarClient.logout();

};
exports.runTask = runTask;