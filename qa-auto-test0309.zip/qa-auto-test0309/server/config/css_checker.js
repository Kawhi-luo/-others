exports.config = {
    "filterRegs": [
        "ac-globalnav.built.css",
        "ac-globalfooter.built.css",
        "ac-localnav.built.css",
        "fonts?"
    ]
};