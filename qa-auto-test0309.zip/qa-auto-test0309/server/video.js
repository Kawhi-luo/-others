const adapter = require('../service/adapter'),
    q = require('../service/query'),
util = require("../service/util");

const URL = require('url');

const getVideo = (url, auth, cb) => {
    url = util.urlNormalize(url);
    q.query(url, (err, res) => {
        if(!err){
            adapter.mp4Handler(res, (err, data) => {
                let res = {
                    url,
                    total : data.length,
                    list : []
                };
                data.forEach(item => {
                    res.list.push(URL.resolve(url, item));
                });
                cb(err, res);
            });
        }else{
            cb(err, []);
        }
    }, auth, {});
};
let geoCheck = (geoUrl,auth) => {
    return new Promise((resolve, reject) =>{
        getVideo(geoUrl, auth, (err, data) => {
            if(!err){
                resolve(data);
            }else{
               reject(data);
            }
        })
    })
};
let usCheck = (usUrl, auth) => {
    return new Promise((resolve, reject) => {
        getVideo(usUrl, auth, (err, data) => {
            if(!err){
               resolve(data);
            }else{
                reject(data);
            }
        })
    })
};
let videoQuery = async (url,auth)=>{
    let geoUrl = url;
    let usUrl;
    let GEO = ['/cn/','/hk/en/','/hk/','/mo/','/tw/'];
    for(let i=0;i<GEO.length;i++){
        if(url.indexOf(GEO[i]) !==-1){
            usUrl = url.replace(GEO[i],'/');
            break;
        }
    }
    let promises = [geoCheck(geoUrl,auth),usCheck(usUrl, auth)];
    let res ={};
    return await Promise.all(promises).then(value =>{
        res['geoUrl'] = value[0];
        res['usUrl'] = value[1];
        // console.log(res);
        return res;
    }).catch(err =>{
        res.message = err.message;
        return res;
    })
};
exports.videoQuery = videoQuery;
exports.getVideo = getVideo;