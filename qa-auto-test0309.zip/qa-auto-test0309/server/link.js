const adapter = require('../service/adapter'),
    q = require('../service/query'),
    util = require('../service/util'),
    basic = require('../service/basic'),
    gh = require('../service/geo_helper'),
    async = require('async'),
request = require('request');

const URL = require("url");

const linkCheckerConf = require('./config/link_checker').config || {};

const getLinks =  (url, auth, cb) => {
    url = util.urlNormalize(url);
    const geo = gh.getGEO(url);
    q.query(url, (err, data) => {
        if (!err) {
        adapter.linkHandler(data, (err, arr) => {
            if (!err) {
            let res = [[],[],[]];
            arr[0].forEach(item => {
                res[0].push(judgeUrl(url, item, geo));
        });
            arr[1].forEach(item => {
                    res[1].push(judgeUrl(url, item, geo));

        });
            arr[2].forEach(item => {
                res[2].push(judgeUrl(url, item, geo));
        });
                async.mapLimit(res,3,(content,callback) => {
                async.mapLimit(content, 10, (item,cb1) => {
                    q.itemQuery(item,auth,cb1);
                },(err,results) => {
                    callback(null,results);
                });
                },(err,results) => {
                   cb(results);
                })
        } else {
            cb(err);
        }
    });

    } else {
        cb(err);
    }
}, auth, {});
};
const getLinkswf =  (url, auth, cb) => {
    url = util.urlNormalize(url);
    const geo = gh.getGEO(url);
    q.query(url, (err, data) => {
        if (!err) {
            adapter.linkHandler(data, (err, arr) => {
                if (!err) {
                    let res = [[],[],[]];
                    arr[0].forEach(item => {
                        res[0].push(judgeUrl(url, item, geo));
                    });
                    arr[1].forEach(item => {
                        res[1].push(judgeUrl(url, item, geo));

                    });
                    arr[2].forEach(item => {
                        res[2].push(judgeUrl(url, item, geo));
                    });
                    async.mapLimit(res,3,(content,callback) => {
                        async.mapLimit(content, 10, (item,cb1) => {
                            q.itemQuery(item,auth,cb1);
                        },(err,results) => {
                            callback(null,results);
                        });
                    },(err,results) => {
                        cb(err,results);
                    })
                } else {
                    cb(err);
                }
            });

        } else {
            cb(err);
        }
    }, auth, {});
};
Array.prototype.unique = function () {
    let res = [];
    let json = {};
    for (let i = 0; i < this.length; i++) {
        if (!json[this[i]]) {
            res.push(this[i]);
            json[this[i]] = 1;
        }
    }
    return res;
};

const judgeUrl = (origin, urlObj, geo) => {

    let tempUrl = URL.resolve(origin, urlObj.tempUrl);
    let objText = urlObj.text.replace(/\/t/g, '').replace(/\/n/g, '');
    let finalText = objText.split('\t').join('').split('\n').join('');
    let tempHost = URL.parse(tempUrl).hostname.split('.')[0];
    let obj = {
        type: null,
        href: tempUrl,
        status: null,
        message: null,
        rawLink: urlObj.tempUrl,
        text: finalText
    };
    if(tempUrl.indexOf('/shop/goto') ===-1){
        obj.toWWW = null;
    }else{
        if(tempHost ==='www'){
            obj.toWWW = null;
        }else{
            obj.toWWW = tempUrl.replace(tempHost,'www');
        }
    }
    let host = URL.parse(tempUrl).hostname;
    let originHost = URL.parse(origin).hostname;

    const filter = linkCheckerConf['filter'] || [];
    const extFilter = linkCheckerConf['ext-filter'] || [];
    const deformity = linkCheckerConf['deformity'] || {};
    let deformityList = [];
    for (let d in deformity) {
        if (deformity.hasOwnProperty(d)) {
            deformityList.push(d);
        }
    }
    let tempDeformity = deformityList.find(item => {
        return tempUrl.indexOf(item) !== -1
    });

    if (host !== originHost && host.indexOf('apple.com') === -1 && extFilter.indexOf(host) === -1) {

        obj.type = 'external';
        obj.status = 'pass';

    } else if (!util.filter(tempUrl, filter)) {

        obj.type = 'blacklist';
        obj.status = 'pass';

    } else if (tempDeformity) {

        obj.type = 'deformity';
        if (deformity[tempDeformity][geo.toLowerCase()]) {
            let regStr = deformity[tempDeformity][geo.toLowerCase()];
            if (tempUrl.indexOf(regStr) !== -1) {
                obj.status = 'pass';
            } else {
                obj.status = 'failed';
                obj.message = `No GEO String ,${regStr} Required for ${tempUrl.tempUrl}`;
            }
        } else {
            obj.status = 'pass';
        }

    } else {

        obj.type = 'normal';
        if (gh.isGEO(tempUrl, geo)) {
            obj.status = 'pass';
        } else {
            obj.status = 'failed';
            obj.message = `No GEO string , ${geo} Required for ${URL.parse(tempUrl).pathname}`;
        }

    }


    if (obj.type !== 'normal') {
        // console.log(obj);
    }

    return obj;
};
exports.getLinks = getLinks;
exports.getLinkswf = getLinkswf;