
const async = require('async');

const comp = require('../service/copycustom');

let MAX_THREAD = 20;

const runTask = (urls, auth, cb) => {


    comp.compare(urls, auth, (err, data) => {
        cb(data);


    })

};
exports.runTask = runTask;