const query = require('../service/query'),
    URL = require('url'),
    async = require('async'),
    util  = require('./util'),
    cheerio = require('cheerio');


let compare = (urls, auth, cb) => {
    let url1=urls[0];
    let url2=urls[1];

    console.log(url1);
    console.log(url2);
    if(url1.indexOf('interactive-gallery') ===-1 && url2.indexOf('interactive-gallery') ===-1){
        async.parallel([
            callback => {
                query.query(url1, callback, auth);
            },

            callback => {
                query.query(url2, callback, auth);
            }

        ], function (err, res) {
            let arr = [[], []];
            // console.log(res);
            if (!err && res[0] && res[1] ) {
                arr = _comp(_getContent(res[0]), _getContent(res[1]));
            } else {
                console.log(`\t[ X ] : Fetching information on ${url1}/${url2} failed, with an error of ${err.message}`);
            }

            cb(err, arr);
        });
    }else if(url1.indexOf('interactive-gallery') !==-1 && url2.indexOf('interactive-gallery') ===-1){
        cb(null,'Something wrong with the urls');
    }else if(url1.indexOf('interactive-gallery') ===-1 && url2.indexOf('interactive-gallery') !==-1) {
        cb(null,'Something wrong with the urls');
    }else{
        async.parallel([
            callback => {
                query.query(url1, callback, auth);
            },
            callback => {
                query.query(url2,callback,auth);
            }
        ], function (err, res) {
            let arr = [];
            if (!err && res[0]  && res[1]) {
                let url1_kua = _getContentwg(res[0])[0];
                let url2_kua = _getContentwg(res[1])[0];
                let Kun = [];
                Kun = compareUrl(url1_kua,url2_kua);
                let url1_dai = _getContentwg(res[0])[1];
                let url2_dai = _getContentwg(res[1])[1];
                let Dai = [];
                Dai = compareUrl(url1_dai,url2_dai);
                let url1_pan = _getContentwg(res[0])[2];
                let url2_pan = _getContentwg(res[1])[2];
                let Pan =[];
                Pan = compareUrl(url1_pan,url2_pan);
                arr = [Kun,Dai,Pan];
            } else {
                console.log(`\t[ X ] : Fetching shared images on ${urls} failed, with an error of ${err.message}`);
                // console.log(`${online_url} missed:\n\t${arr[0].join('\n\t')}\n\n${url} added:\n\t${arr[1].join('\n\t')}`);
            }
            cb(null, arr);
        });
    }
};
//比较url1，url2
let compareUrl = (url1Arr,url2Arr) => {

        let url1Data = [];
        let url2Data = [];
        let newUrl1 = [];
        let newUrl2 = [];
        let Data = [];
        let fData = [];
        for(let i=0;i<url1Arr.length;i++){
            if(url1Arr[i].id){
                newUrl1.push(url1Arr[i]);
            }
        }
    for(let i=0;i<url2Arr.length;i++){
        if(url2Arr[i].id){
            newUrl2.push(url2Arr[i]);
        }
    }
        for(let i=0;i<newUrl1.length;i++){
                url1Data[i] = newUrl1[i];
                for(let j=0;j<newUrl2.length;j++){
                    // if(url2Arr[j].id){
                        if(newUrl1[i].id === newUrl2[j].id){
                           url2Data[i] = newUrl2[j];
                        }
                }
            Data[i] = [newUrl1[i].id,url1Data[i],url2Data[i]];
        }
        for(let i=0;i<Data.length;i++){
            if(Data[i][1]){
                fData.push(Data[i]);
            }
        }
    return fData;
}
let _getContent = (str) => {
    let $ = cheerio.load(str);
    let _text;
    if ($(".section-buystrip-hero")) {
        if ($(".section-buystrip-hero").parent().is(".main")) {
            if ($("main")) {
                if ($("main").parent().is("main")) {
                    _text = $('#main,section.wcfooter-sosumi,section.ac-gf-sosumi,nav.ac-gf-breadcrumbs').text();
                } else {
                    _text = $('main,#main,.main,section.wcfooter-sosumi,section.ac-gf-sosumi,nav.ac-gf-breadcrumbs').text();
                }
            }
            else {
                _text = $('#main,.main,section.wcfooter-sosumi,section.ac-gf-sosumi,nav.ac-gf-breadcrumbs');
            }
        } else {
            _text = $('main,#main,.main,section.wcfooter-sosumi,section.ac-gf-sosumi,nav.ac-gf-breadcrumbs,.section-buystrip-hero').text();
        }
    } else {
        _text = $('main,#main,.main,section.wcfooter-sosumi,section.ac-gf-sosumi,nav.ac-gf-breadcrumbs').text();
    }
    Array.prototype.unique = function(){
        let res = [];
        let json = {};
        for(let i = 0; i < this.length; i++){
            if(!json[this[i]]){
                res.push(this[i]);
                json[this[i]] = 1;
            }
        }
        return res;
    };

    let _textArr = _text.split('\t').join('').split('\n');
    // let _texArr = _textArr.unique();
    let newArr=[];
    for(let i=0;i<_textArr.length;i++){
        if(_textArr[i] !== ''){
            newArr.push(_textArr[i].trim());
        }
    }
    for(let j=0;j<newArr.length;j++){
        newArr[j].split(' ').join('&nbsp;');
    }
    // let textArr = _text.split('\n'), arr = [];
    let arr = [];
    newArr.map(item => {
        let temp = item.replace(/\s/g, ' ');
        if (temp.length > 0 && temp.replace(/ /g, '').length > 0) {
            arr.push(temp);
        }
    });

    return arr;
};
let _getContentwg = (str) => {
    let $ = cheerio.load(str);
    let danwei = $('#gallery-container');
    let dw = danwei.attr('data-string-size');
    dw = dw.replace('{size}','');
    // 表盘
    let _text2 = $(".gallery-watch");
    let arr_pan = [];//表盘属性
    let pan_obj = {animation: [], animation_locale: [], aria_label: [], id: [],data_size: []};
    _text2.each(function (i, elem) {
        pan_obj.animation[i] = $(this).attr("data-animation");
        pan_obj.animation_locale[i] = $(this).attr('data-animation-locale');
        pan_obj.aria_label[i] = $(this).attr('aria-label');
        pan_obj.id[i] = $(this).attr('id');
        pan_obj.data_size[i] = $(this).attr('data-size');
        if (pan_obj.aria_label.join(',').indexOf("表盘") === -1) {
            arr_pan[i] = {
                'id': pan_obj.id[i],
                'data-animation': pan_obj.animation[i],
                'data-animation-locale': pan_obj.animation_locale[i],
                'aria-label': pan_obj.aria_label[i],
                'data-size': pan_obj.data_size[i] + dw
            }
        }else{
            arr_pan[i] = {
                'id': pan_obj.id[i],
                'data-animation': pan_obj.animation[i],
                'data-animation-locale': pan_obj.animation_locale[i],
                'aria-label': pan_obj.aria_label[i],
                'data-size': pan_obj.data_size[i] + dw
            }
        }
    });
    arr_pan.shift();
    //表款
    let kua_obj = {
        casing_name: [],
        band_name: [],
        aria_label: [],
        data_size: [],
        sku_model: [],
        string_size: [],
        id: []
    };
    let arr_kua = [];//表款属性
    let _text3 = $("div.gallery-band-visible,div#gallery-cases,div.gallery-content-pane");
    _text3.each(function (i, elem) {
        kua_obj.aria_label[i] = $(this).attr('aria-label');
        kua_obj.casing_name[i] = $(this).attr('data-casing-name');
        kua_obj.band_name[i] = $(this).attr('data-band-name');
        kua_obj.sku_model[i] = $(this).attr('data-sku-model');
        kua_obj.data_size[i] = $(this).attr('data-size');
        kua_obj.string_size[i] = $(this).attr('data-string-size');
        kua_obj.id[i] = $(this).attr('id');

        if (kua_obj.aria_label.join(',').indexOf("表带") === -1) {

            arr_kua[i] = {
                "id": kua_obj.id[i],
                'aria-label': kua_obj.aria_label[i],
                'data-casing-name': kua_obj.casing_name[i],
                'data-band-name': kua_obj.band_name[i],
                'data-string-size': kua_obj.string_size[i],
                'data-size': kua_obj.data_size[i] + dw,
                'data-sku-model': kua_obj.sku_model[i]
            }
        } else {
            arr_kua[i] = {
                "id": kua_obj.id[i],
                'aria-label': kua_obj.aria_label[i],
                'data-casing-name': kua_obj.casing_name[i],
                'data-band-name': kua_obj.band_name[i],
                'data-string-size': kua_obj.string_size[i],
                'data-size': kua_obj.data_size[i] + dw,
                'data-sku-model': kua_obj.sku_model[i]
            }
        }
    });
    arr_kua.shift();
    arr_kua.shift();
    //表带
    let _text4 = $(".gallery-band-container,#gallery-bands");
    let dai_obj = {
        data_size: [],
        data_background: [],
        band_available: [],
        band_unavailable: [],
        data_hidden: [],
        aria_label: [],
        data_buy: [],
        id: []
    };
    let arr_dai = [];//表带属性
    _text4.each(function (i, elem) {
        dai_obj.data_size[i] = $(this).attr("data-size");
        dai_obj.data_background[i] = $(this).attr("data-background");
        dai_obj.band_available[i] = $(this).attr("data-band-available");
        dai_obj.band_unavailable[i] = $(this).attr("data-band-unavailable-copy");
        dai_obj.data_hidden[i] = $(this).attr("data-hidden");
        dai_obj.aria_label[i] = $(this).attr("aria-label");
        dai_obj.data_buy[i] = $(this).attr("data-buy");
        dai_obj.id[i] = $(this).attr('id');
        if (dai_obj.aria_label.join(',').indexOf("表带") === -1) {
            arr_dai[i] = {
                'id': dai_obj.id[i],
                'aria-label': dai_obj.aria_label[i],
                'data-size': dai_obj.data_size[i] + dw,
                'data-background': dai_obj.data_background[i],
                'data-band-available': dai_obj.band_available[i],
                'data-band-unavailable-copy': dai_obj.band_unavailable[i],
                'data-hidden': dai_obj.data_hidden[i],
                'data-buy': dai_obj.data_buy[i]
            }
        } else {
            // arr_dai.push('id:' + dai_obj.id[i]+ '<br>' + 'aria-label:' + dai_obj.aria_label[i] + "<br>" + 'data-size:' + dai_obj.data_size[i] + "毫米" + "<br>" + 'data-background:' + dai_obj.data_background[i] + "<br>" + 'data-band-available:' + dai_obj.band_available[i] + "<br>" + "data-band-unavailable-copy:" + dai_obj.band_unavailable[i] +"<br>"+ "data-hidden:" + dai_obj.data_hidden[i] + + "<br>" + "data-buy:" + dai_obj.data_buy[i] + "<br>");
            arr_dai[i] = {
                'id': dai_obj.id[i],
                'aria-label': dai_obj.aria_label[i],
                'data-size': dai_obj.data_size[i] + dw,
                'data-background': dai_obj.data_background[i],
                'data-band-available': dai_obj.band_available[i],
                'data-band-unavailable-copy': dai_obj.band_unavailable[i],
                'data-hidden': dai_obj.data_hidden[i],
                'data-buy': dai_obj.data_buy[i]
            }
        }
    });
    arr_dai.shift();
    let arr = [];
    arr[0] = arr_kua;
    arr[1] = arr_dai;
    arr[2] = arr_pan;
    return arr;

};
let _comp = (baseArr, targetArr) => {
    let sameArr = [], oldArr = [], newArr = [];
    for (let i = 0; i < targetArr.length; i++) {
        if (baseArr.indexOf(targetArr[i]) === -1) {
            newArr.push(targetArr[i]);

        } else {
            sameArr.push(targetArr[i]);
        }
    }

    for (let j = 0; j < baseArr.length; j++) {
        if (targetArr.indexOf(baseArr[j]) === -1) {
            oldArr.push(baseArr[j]);
        }
    }
    // return [sameArr, oldArr, newArr];
    return [ oldArr, newArr];
};
exports.compare = compare;





