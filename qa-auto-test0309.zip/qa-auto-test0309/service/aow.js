const query = require('../service/query'),
    URL = require('url'),
    async = require('async'),
    util = require('./util'),
    fs = require('fs'),
    ejs = require('ejs'),
    cheerio = require('cheerio'),
    lodash = require('lodash'),
    conf = require('../server/config/config'),
    adapter = require('./adapter'),
    request = require('request');

let promisedQuery = (url, auth) => {
    return new Promise((resolve, reject) => {
        query.query(url, (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        }, auth);
    });
};

let compare = async (url, auth) => {

    if (!URL.parse(url).protocol) {

        url = 'https://' + url;
    } else {
        if (URL.parse(url).protocol !== 'https:') {
            url = util.urlNormalize(url);
        }
    }
    let res = [
        await promisedQuery(url, auth),
        await promisedQuery(url.replace('aow/', ''), auth)
    ];
    let arr = [];

    let Tag1 = 'html';
    let Tag2 = 'link';
    let Tag3 = {
        aside: 'aside',
        meta: 'meta',
        input: 'input',
        nav: 'nav',
        div: 'div',
        phdiv: 'div',
        script: 'script',
        link: 'link',
        emdiv: 'div'
    };
    let Tag4 = 'link';
    let Tag5 = {
        footer: 'footer',
        div1: 'div',
        h2: 'h2',
        section1: 'section',
        section2: 'section',
        section3: 'section',
        div2: 'div',

    };
    let Tag10 = 'link';
    let Tag11 = 'p';
    let Tag12 = 'link';
    let Tag13 = 'link';
    let Tag14 = 'link';
    let Tag17 = 'link';
    let Tag18 = {
        div: 'div',
        img: 'img',
        body: 'body'
    };
    let Tag19 = 'meta';
    let Tag20 = {
        img: 'img',
        link: 'link'
    };
    let Tag21 = 'link';
    let Tag22 = 'a';
    let Tag23 = {
        a: 'a',
        meta: 'meta'
    };
    arr = [
        url,
        htmlAowTestCheck(res[0], Tag1),
        sfIconsTest(url, res[0], Tag2),
        globalNavRemoveTest(res[0], Tag3),
        allCssLinkStartWithCnAowAddedTest(res[0], Tag4),
        footerChangeTest(res[0], Tag5, url),
        buyStripRemoveTest(res[0]),
        breadcrumbsNavRemoveTest(res[0]),
        originalFooterRemoveTest(res[0]),
        hreflangRemoveTest(res[0]),
        localNaveCssTest(res[0], Tag10),
        buyStripBuiltCssRemoveTest(res[0], Tag12),
        wssFontCssRemoveTest(res[0], Tag13),
        sfproCssRemoveTest(res[0], Tag14),
        ifIeRemoveTest(res[0]),
        fontIncRemoveTest(res[0]),
        fontCssRemoveTest(res[0], Tag17, url),
        socialShareImageDisplayOnceTest(res[0], Tag18),
        metaTagsLinkTest(res[0], Tag19),
        allImageLinkStartWithCnAowAddedTest(res[0], Tag20),
        canonicalKeepTheSameTest(res[0], res[1], Tag21, url),
        aowPagelinkInAnotherPageAowAddedTest(res[0], Tag22,url),
        await returnStatusCodeTest(res[0], Tag23, url, auth)
    ];
    return arr;

};
//判断数组中包含某值
let listInclude = (arrName, url) => {
    let prefix = url.split('.com')[0] + '.com';
    let arr = [];
    if (arrName === "urlWithBuyStripType1") {
        for (let i = 0; i < conf.type.type1.length; i++) {
            arr[i] = conf.type.type1[i];
        }
    }
    if (arrName === "urlWithBuyStripType2") {
        for (let i = 0; i < conf.type.type2.length; i++) {
            arr[i] = conf.type.type2[i];
        }
    }
    for (let j = 0; j < arr.length; j++) {
        let tempUrl = prefix + arr[j];
        if (tempUrl === url) {
            return true;
        }
    }
    return false;
};
Array.prototype.contains = function ( needle ) {
    for (let i in this) {
        if (this[i] === needle) return true;
    }
    return false;
}
//1
let htmlAowTestCheck = (str, node) => {
    let $ = cheerio.load(str);
    let nodeClass = $(node).attr('class');
    let obj = {
        rule: 'htmlAow_test',
        result: null,
        description: []
    };
    if (nodeClass.indexOf('aow') !== -1) {
        obj.result = 'Pass';
        obj.description.push('Html ClasName = ' + nodeClass);
    } else {
        obj.result = 'Failed';
        obj.description.push('Html ClasName = ' + nodeClass);
    }
    return obj;
};


//2
let sfIconsTest = (url, str, node) => {
    let $ = cheerio.load(str);
    let links = $(node);
    let newUrl = url.split('/cn/')[0] + '/';
    let tag = 0
    ;let obj = {
        rule: 'sfIcons_test',
        result: null,
        description: []
    };
    if (links) {
        for (let i = 0; i < links.length; i++) {
            if (links[i].attribs.href.indexOf('/wss/fonts?families') !== -1 && links[i].attribs.href !== newUrl + "/wss/fonts?families=SF+Pro+Icons,v1") {
                obj.result = 'Failed';
                obj.description.push("Not needed to add the " + links[i].attribs.href);
            }
            if (links[i].attribs.href.indexOf("/wss/fonts?families=SF+Pro+Icons,v1") !== -1) {
                obj.result = 'Pass';
                obj.description.push("Link href = " + links[i].attribs.href);
                tag++;
            }
        }
        if (tag === 0) {
            obj.result = 'Failed';
            obj.description.push("No link’s href attribute equal to '/wss/fonts?families=SF+Pro+Icons,v1'");
        }
        if (tag > 1) {
            obj.result = 'Failed';
            obj.description.push("More than 1 string like this /wss/fonts?families=SF+Pro+Icons,v1 appears");
        }
    } else {
        obj.result = 'Failed';
        obj.description.push("Exception message: Failed, not find link’s href attribute");
    }

    return obj;
};

//3
let globalNavRemoveTest = (str, nodeObj) => {
    let tag = 0;
    let tagError = 0;
    let $ = cheerio.load(str);
    let metas = $(nodeObj.meta);
    let obj = {
        rule: 'globalNavRemove_test',
        result: null,
        description: []
    };
    if (metas) {
        for (let i = 0; i < metas.length; i++) {
            if (metas[i] && metas[i].name === 'ac-gn-store-key') {
                obj.result = 'Failed';
                obj.description.push('Ac-gn-store-key appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push("Exception message: There is no meta tag or no ac-gn-store-key id attribute");
        tagError++;
    }
    let asides = $(nodeObj.aside);
    if (asides) {
        for (let i = 0; i < asides.length; i++) {
            if (asides[i].attribs.id && asides[i].attribs.id === 'ac-gn-segmentbar') {
                obj.result = 'Failed';
                obj.description.push('Ac-gn-segmentbar appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push("Exception message: There is no aside tag or ac-gn-segmentbar id attribute");
        tagError++;

    }
    let inputs = $(nodeObj.input);
    if (inputs) {
        for (let i = 0; i < inputs.length; i++) {
            if (inputs[i].attribs.id && inputs[i].attribs.id === 'ac-gn-menustate') {
                obj.result = 'Failed';
                obj.description.push('ac-gn-menustate appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push("Exception message: There is no input tag or no ac-gn-menustate id attribute");
        tagError++;
    }
    let navs = $(nodeObj.nav);
    if (navs) {
        for (let i = 0; i < navs.length; i++) {
            if (navs[i].attribs.id && navs[i].attribs.id === 'ac-globalnav') {
                obj.result = 'Failed';
                obj.description.push('ac-globalnav appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push("Exception message: There is no nav tag or no ac-globalnav id attribute");
        tagError++;
    }
    let divs = $(nodeObj.div);
    if (divs) {
        for (let i = 0; i < divs.length; i++) {

            if (divs[i] && divs[i].attribs.id === 'ac-gn-curtain') {
                obj.result = 'Failed';
                obj.description.push('ac-gn-curtain appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push("Exception message: There is no div tag or no ac-gn-curtain id attribute");
        tagError++;
    }
    let phdivs = $(nodeObj.phdiv);
    if (phdivs) {
        for (let i = 0; i < phdivs.length; i++) {

            if (phdivs[i] && phdivs[i].attribs.id === 'ac-gn-placeholder') {
                obj.result = 'Failed';
                obj.description.push('ac-gn-placeholder appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push("Exception message: There is no div tag or no ac-gn-placeholder id attribute");
        tagError++;
    }
    let scripts = $(nodeObj.script);
    if (scripts) {
        for (let i = 0; i < scripts.length; i++) {
            if (scripts[i].attribs.src && scripts[i].attribs.src.indexOf("ac-globalnav.built.js") !== -1) {
                obj.result = 'Failed';
                obj.description.push('ac-globalnav.built.js appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push("Exception message: There is no script tag or no ac-globalnav.built.js");
        tagError++;
    }
    let links = $(nodeObj.link);
    if (links) {
        for (let i = 0; i < links.length; i++) {
            if (links[i].attribs.href && links[i].attribs.href.indexOf("ac-globalnav.built.css") !== -1) {
                obj.result = 'Failed';
                obj.description.push('ac-globalnav.built.css appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push("Exception message: There is no link tag or no ac-globalnav.built.css");

        tagError++;
    }

    let emdivs = $(nodeObj.emdiv);
    if (emdivs) {
        for (let i = 0; i < emdivs.length; i++) {

            if (emdivs[i] && emdivs[i].attribs.id === "ac-gn-viewport-emitter") {
                obj.result = 'Failed';
                obj.description.push('ac-gn-viewport-emitter appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push("Exception message: There is no script tag or no ac-gn-viewport-emitter id attribute");

        tagError++;
    }
    if (tag === 0 && tagError === 0) {
        obj.result = "Pass";
        obj.description.push('Global Nav related items are all removed');
    }
    return obj;
}
//4
let allCssLinkStartWithCnAowAddedTest = (str, node) => {
    let $ = cheerio.load(str);
    let obj = {
        rule: 'allCssLinkStarWithCnAowAddedTest',
        result: null,
        description: []
    };
    let links = $(node);
    let tag = 0;
    let tagError = 0;
    let hr;
    let flag;
    if (links) {
        for (let i = 0; i < links.length; i++) {
            if (links[i].attribs.href && links[i].attribs.rel) {
                if (links[i].attribs.href.indexOf('.com') !== -1) {
                    hr = links[i].attribs.href.split('.com')[1];
                } else {
                    hr = links[i].attribs.href;
                }
                if (links[i].attribs.rel !== 'canonical' && links[i].attribs.rel.indexOf('stylesheet') !== -1) {
                    for (let j = 0; j < conf.mowUrl.length; j++) {
                        if (hr === conf.mowUrl[j]) {
                            flag = 1;
                        } else {
                            flag = 0;
                        }
                    }
                    if (flag) {
                        if (links[i].attribs.href.indexOf('aow') !== -1) {
                            obj.result = "Pass";
                            obj.description.push("Aow appears in css links which start with /cn, the css url is " + links[i].attribs.href);
                        } else {
                            obj.result = 'Failed';
                            obj.description.push('Aow not appears in css links which start with /cn, the css url is' + links[i].attribs.href);
                        }
                        tag++;
                    }
                }

            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push('Exception message: Did not find any link or no href attribute appears');
        tagError++;
    }
    if (tag === 0 && tagError === 0) {
        obj.result = 'Pass';
        obj.description.push('No CSS contains /cn/PRODUCT_NAME/(which list in our testing site)');
    }
    return obj;
}
//5
let footerChangeTest = (str, nodeObj, url) => {
    if (str.indexOf('section class=\"ac-gf-buystrip\"') !== -1) {
        let $ = cheerio.load(str);
        let footers = $(nodeObj.footer);
        let tag1 = 0;
        let tagError1 = 0;
        let obj = {
            rule: "footerChange_test",
            result: null,
            description: []
        };
        let s1Html = $(nodeObj.footer).children().last().html();
        let s1Class = $(nodeObj.section1,s1Html)[0].attribs.class;
        let s2Class = $(nodeObj.section1,s1Html)[2].attribs.class;
        if(s1Class === 'wcfooter-help'){
            let idName = footers[0].attribs.id;
            let ariaLabelLedby = footers[0].attribs['aria-labelledby'];
            if (footers) {
                if (footers.length > 1) {
                    obj.description.push("There are more than one footer tag");
                } else if (footers.length === 1) {
                    if (idName === "wcfooter" && ariaLabelLedby === "wcfooter-label") {
                        obj.result = 'Pass';
                        obj.description.push('Point 1 Pass,footer ID = wcfooter and ariaLabelLedby = wcfooter-label');
                        tag1++;
                    }
                }
            } else {
                obj.result = 'Failed';
                obj.description.push('Exception message: Point 1 Did not find footer or no id/aria-labelledby attribute appears');
                tagError1++;
            }
            if (tag1 === 0 && tagError1 === 0) {
                obj.result = "Failed";
                obj.description.push('Point 1 Fail,footer ID != wcfooter or ariaLabelLedby != wcfooter-label');
            }
            let tag2 = 0;
            let tagError2 = 0;
            if (tag1 === 1) {
                let div1Class = $(nodeObj.div1, nodeObj.footer)[1].attribs.class;
                if (div1Class) {
                    if (div1Class === "wcfooter-content") {
                        obj.result = 'Pass';
                        obj.description.push('Point 2 Pass,footer 1st div class = wcfooter-content');
                        tag2++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push("Exception message: Point 2 Did not find div or no attribute appears");
                    tagError2++;
                }
                if (tag2 === 0 && tagError2 === 0) {
                    obj.result = "Failed";
                    obj.description.push("Point 2 Fail,footer 1st div class != wcfooter-content");
                }

            }

            let tag3 = 0;
            let tagError3 = 0;
            if (tag1 === 1 && tag2 === 1) {
                let h2Html = $(nodeObj.footer).children().last().html();
                let h2Class = $(nodeObj.h2, h2Html)[0].attribs.class;
                let h2Id = $(nodeObj.h2, h2Html)[0].attribs.class;
                if (h2Class && h2Id) {
                    if (h2Class === 'wcfooter-label' && h2Id === 'wcfooter-label') {
                        obj.result = 'Pass';
                        obj.description.push('Point 3 Pass,footer 1st div 1st h2 class and id = wcfoooter-label');
                        tag3++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push(" Exception message: Point 3 Did not find h2 or no attribute appears");
                    tagError3++;
                }
                if (tag3 === 0 && tagError3 === 0) {
                    obj.result = 'Failed';
                    obj.description.push("Point 3 Fail,footer 1st div 1st h2 class or id != wcfooter-label");
                }

            }

            let tag4 = 0;
            let tagError4 = 0;
            if (tag1 === 1 && tag2 === 1) {
                let section1Html = $(nodeObj.footer).children().last().html();
                let section1Class = $(nodeObj.section1, section1Html)[0].attribs.class;
                if (section1Class) {
                    if (section1Class === 'wcfooter-help') {
                        obj.result = "Pass";
                        obj.description.push('Point 4 Pass,footer 1st div 1st section class = wcfooter-help');
                        tag4++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Point 4 Div not find section or no attribute appears');
                    tagError4++;
                }
            }
            if (tag4 === 0 && tagError4 === 0) {
                obj.result = 'Failed';
                obj.description.push('Point 4 Fail, footer 1st div 1st section class != wcfooter-help');
            }
            let tag5 = 0;
            let tagError5 = 0;
            if (tag1 === 1 && tag2 === 1) {
                let section2Html = $(nodeObj.footer).children().last().html();
                let section2Class = $(nodeObj.section2, section2Html)[1].attribs.class;
                if (section2Class) {
                    if (section2Class === 'wcfooter-qr') {
                        obj.result = "Pass";
                        obj.description.push('Point 5 Pass,footer 1st div 2nd section class = wcfooter-qr');
                        tag5++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Point 5 Did not find section or no attribute appears');
                    tagError5++;
                }
                if (tag5 === 0 && tagError5 === 0) {
                    obj.result = 'Failed';
                    obj.description.push('Point 5 Fail,footer 1st div 2nd section class != wcfooter-qr');
                }
            }

            let tempUrl = url.split('.com')[1];
            if (tempUrl === '/cn/mac-mini/aow/') {
                obj.result = 'Pass';
                obj.description.push('The is a special link, do not check point 6, 7 ,8');
                return obj;
            }

            let tag6 = 0;
            let tagError6 = 0;
            if (tag1 === 1 && tag2 === 1) {
                let section3Html = $(nodeObj.footer).children().last().html();
                let section3Class = $(nodeObj.section3, section3Html)[2].attribs.class;
                let section3label = $(nodeObj.section3, section3Html)[2].attribs['aria-label'];
                if (section3label && section3Class) {
                    if (section3Class === 'wcfooter-sosumi' && section3label === 'Footnotes') {
                        obj.result = "Pass";
                        obj.description.push('Point 6 Pass,footer 1st div 3rd section class = wcfooter-sosumi');
                        tag6++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Point 6 Did not find section or no attribute appears');
                    tagError6++;
                }
                if (tag6 === 0 && tagError6 === 0) {
                    obj.result = 'Failed';
                    obj.description.push('Point 6 Fail,footer 1st div 3rd section class != wcfooter-sosumi');
                }
            }

            let tag7 = 0;
            let tagError7 = 0;
            if (tag1 === 1 && tag2 === 1) {
                let section3Html = $(nodeObj.footer).children().last().html();
                if (section3Html) {
                    if($(nodeObj.section3, section3Html)[3]){
                        let section3Class = $(nodeObj.section3, section3Html)[3].attribs.class;
                        if (section3Class === 'wcfooter-mini') {
                            obj.result = "Pass";
                            obj.description.push('Point 7 Pass,footer 1st div 4th section class = wcfooter-mini');
                            tag7++;
                        }
                    }

                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Point 7 Did not find section or no attribute appears');
                    tagError7++;
                }
                if (tag7 === 0 && tagError7 === 0) {
                    obj.result = 'Failed';
                    obj.description.push('Point 7 Fail,footer 1st div 4th section class != wcfooter-mini');
                }
            }

            let tag8 = 0;
            let tagError8 = 0;
            if (tag1 === 1 && tag2 === 1 && tag7 === 1) {
                let divHtml = $( nodeObj.footer).html();
                let div2Html = $(nodeObj.section1, divHtml).last().html();
                let divClass = $(nodeObj.div1, div2Html)[0].attribs.class;
                if (divClass) {
                    if (divClass === 'wcfooter-mini-legal') {
                        obj.result = "Pass";
                        obj.description.push('Point 8 Pass,footer 1st div 4th section 1st div class = wcfooter-mini-legal');
                        tag8++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Point 8 Did not find section or no attribute appears');
                    tagError8++;
                }
                if (tag8 === 0 && tagError8 === 0) {
                    obj.result = 'Failed';
                    obj.description.push('Point 8 Fail,footer 1st div 4th section 1st div class != wcfooter-mini-legal');
                }
            } else {
                obj.result = "Failed";
                obj.description.push("wcfooter-mini-legal ''s upper level missing");
            }
        }else{
            if(s1Class === 'ac-gf-buystrip' && s2Class === 'wcfooter-help'){
                obj.result = 'N/A';
                obj.description.push('The first section of first div in wcfooter is "ac-gf-buystrip" ,please check it manully');
            }
        }
        return obj;
    }else{
        let $ = cheerio.load(str);
        let footers = $(nodeObj.footer);
        let tag1 = 0;
        let tagError1 = 0;
        let obj = {
            rule: "footerChange_test",
            result: null,
            description: []
        };
        let s1Html = $(nodeObj.div1,nodeObj.footer).html();
        let s1Class = $(nodeObj.section1,s1Html)[0].attribs.class;
        let s2Class = $(nodeObj.section1,s1Html)[2].attribs.class;
        if(s1Class === 'wcfooter-help'){
            let idName = footers[0].attribs.id;
            let ariaLabelLedby = footers[0].attribs['aria-labelledby'];
            if (footers) {
                if (footers.length > 1) {
                    obj.description.push("There are more than one footer tag");
                } else if (footers.length === 1) {
                    if (idName === "wcfooter" && ariaLabelLedby === "wcfooter-label") {
                        obj.result = 'Pass';
                        obj.description.push('Point 1 Pass,footer ID = wcfooter and ariaLabelLedby = wcfooter-label');
                        tag1++;
                    }
                }
            } else {
                obj.result = 'Failed';
                obj.description.push('Exception message: Point 1 Did not find footer or no id/aria-labelledby attribute appears');
                tagError1++;
            }
            if (tag1 === 0 && tagError1 === 0) {
                obj.result = "Failed";
                obj.description.push('Point 1 Fail,footer ID != wcfooter or ariaLabelLedby != wcfooter-label');
            }
            let tag2 = 0;
            let tagError2 = 0;
            if (tag1 === 1) {
                let div1Class = $(nodeObj.div1, nodeObj.footer)[0].attribs.class;
                if (div1Class) {
                    if (div1Class === "wcfooter-content") {
                        obj.result = 'Pass';
                        obj.description.push('Point 2 Pass,footer 1st div class = wcfooter-content');
                        tag2++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push("Exception message: Point 2 Did not find div or no attribute appears");
                    tagError2++;
                }
                if (tag2 === 0 && tagError2 === 0) {
                    obj.result = "Failed";
                    obj.description.push("Point 2 Fail,footer 1st div class != wcfooter-content");
                }

            }

            let tag3 = 0;
            let tagError3 = 0;
            if (tag1 === 1 && tag2 === 1) {
                let h2Html = $(nodeObj.div1, nodeObj.footer).html();
                let h2Class = $(nodeObj.h2, h2Html)[0].attribs.class;
                let h2Id = $(nodeObj.h2, h2Html)[0].attribs.class;
                if (h2Class && h2Id) {
                    if (h2Class === 'wcfooter-label' && h2Id === 'wcfooter-label') {
                        obj.result = 'Pass';
                        obj.description.push('Point 3 Pass,footer 1st div 1st h2 class and id = wcfoooter-label');
                        tag3++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push(" Exception message: Point 3 Did not find h2 or no attribute appears");
                    tagError3++;
                }
                if (tag3 === 0 && tagError3 === 0) {
                    obj.result = 'Failed';
                    obj.description.push("Point 3 Fail,footer 1st div 1st h2 class or id != wcfooter-label");
                }

            }

            let tag4 = 0;
            let tagError4 = 0;
            if (tag1 === 1 && tag2 === 1) {
                let section1Html = $(nodeObj.footer);
                let section1Class = $(nodeObj.section1, section1Html)[0].attribs.class;
                if (section1Class) {
                    if (section1Class === 'wcfooter-help') {
                        obj.result = "Pass";
                        obj.description.push('Point 4 Pass,footer 1st div 1st section class = wcfooter-help');
                        tag4++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Point 4 Div not find section or no attribute appears');
                    tagError4++;
                }
            }
            if (tag4 === 0 && tagError4 === 0) {
                obj.result = 'Failed';
                obj.description.push('Point 4 Fail, footer 1st div 1st section class != wcfooter-help');
            }
            let tag5 = 0;
            let tagError5 = 0;
            if (tag1 === 1 && tag2 === 1) {
                let section2Html = $(nodeObj.div1, nodeObj.footer).html();
                let section2Class = $(nodeObj.section2, section2Html)[1].attribs.class;
                if (section2Class) {
                    if (section2Class === 'wcfooter-qr') {
                        obj.result = "Pass";
                        obj.description.push('Point 5 Pass,footer 1st div 2nd section class = wcfooter-qr');
                        tag5++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Point 5 Did not find section or no attribute appears');
                    tagError5++;
                }
                if (tag5 === 0 && tagError5 === 0) {
                    obj.result = 'Failed';
                    obj.description.push('Point 5 Fail,footer 1st div 2nd section class != wcfooter-qr');
                }
            }

            let tempUrl = url.split('.com')[1];
            if (tempUrl === '/cn/mac-mini/aow/') {
                obj.result = 'Pass';
                obj.description.push('The is a special link, do not check point 6, 7 ,8');
                return obj;
            }

            let tag6 = 0;
            let tagError6 = 0;
            if (tag1 === 1 && tag2 === 1) {
                let section3Html = $(nodeObj.div1, nodeObj.footer).html();
                let section3Class = $(nodeObj.section3, section3Html)[2].attribs.class;
                let section3label = $(nodeObj.section3, section3Html)[2].attribs['aria-label'];
                if (section3label && section3Class) {
                    if (section3Class === 'wcfooter-sosumi' && section3label === 'Footnotes') {
                        obj.result = "Pass";
                        obj.description.push('Point 6 Pass,footer 1st div 3rd section class = wcfooter-sosumi');
                        tag6++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Point 6 Did not find section or no attribute appears');
                    tagError6++;
                }
                if (tag6 === 0 && tagError6 === 0) {
                    obj.result = 'Failed';
                    obj.description.push('Point 6 Fail,footer 1st div 3rd section class != wcfooter-sosumi');
                }
            }

            let tag7 = 0;
            let tagError7 = 0;
            if (tag1 === 1 && tag2 === 1) {
                let section3Html = $(nodeObj.div1, nodeObj.footer).html();
                if (section3Html) {
                    if($(nodeObj.section3, section3Html)[3]){
                        let section3Class = $(nodeObj.section3, section3Html)[3].attribs.class;
                        if (section3Class === 'wcfooter-mini') {
                            obj.result = "Pass";
                            obj.description.push('Point 7 Pass,footer 1st div 4th section class = wcfooter-mini');
                            tag7++;
                        }
                    }

                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Point 7 Did not find section or no attribute appears');
                    tagError7++;
                }
                if (tag7 === 0 && tagError7 === 0) {
                    obj.result = 'Failed';
                    obj.description.push('Point 7 Fail,footer 1st div 4th section class != wcfooter-mini');
                }
            }

            let tag8 = 0;
            let tagError8 = 0;
            if (tag1 === 1 && tag2 === 1 && tag7 === 1) {
                let divHtml = $( nodeObj.footer).html();
                let div2Html = $(nodeObj.section1, divHtml).last().html();
                let divClass = $(nodeObj.div1, div2Html)[0].attribs.class;
                if (divClass) {
                    if (divClass === 'wcfooter-mini-legal') {
                        obj.result = "Pass";
                        obj.description.push('Point 8 Pass,footer 1st div 4th section 1st div class = wcfooter-mini-legal');
                        tag8++;
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Point 8 Did not find section or no attribute appears');
                    tagError8++;
                }
                if (tag8 === 0 && tagError8 === 0) {
                    obj.result = 'Failed';
                    obj.description.push('Point 8 Fail,footer 1st div 4th section 1st div class != wcfooter-mini-legal');
                }
            } else {
                obj.result = "Failed";
                obj.description.push("wcfooter-mini-legal ''s upper level missing");
            }
        }else{
            if(s1Class === 'ac-gf-buystrip' && s2Class === 'wcfooter-help'){
                obj.result = 'N/A';
                obj.description.push('The first section of first div in wcfooter is "ac-gf-buystrip" ,please check it manully');
            }
        }
        return obj;
    }


}

//6
let buyStripRemoveTest = (str) => {
    let obj = {
        rule: "buyStripRemove_test",
        result: null,
        description: []
    }
    let $ = cheerio.load(str);
    let footerHtml = $('footer').html();
    if (str.indexOf('section class=\"ac-gf-buystrip\"') !== -1) {
        if(footerHtml.indexOf('section class=\"ac-gf-buystrip\"') !==-1){
            obj.result = 'Pass';
            obj.description.push('The first section of first div in wcfooter is "ac-gf-buystrip" ,please check it manully');
        }else{
            obj.result = 'Failed';
            obj.description.push('The section is not in wcfooter');
        }
    } else {
        obj.result = 'Pass';
        obj.description.push('Buystrip is removed');
    }
    return obj;
}
//7
let breadcrumbsNavRemoveTest = (str) => {
    let obj = {
        rule: "breadcrumbsNavRemove_test",
        result: null,
        description: []
    }
    if (str.indexOf('<nav class=\"ac-gf-breadcrumbs\" aria-label=\"Breadcrumbs\" role=\"navigation\">') !== -1) {
        obj.result = 'Failed';
        obj.description.push("BreadcrumbsNav still can be found in source code");
    } else {
        obj.result = 'Pass';
        obj.description.push('BreadcrumbsNav is removed');
    }
    return obj;
}

//8
let originalFooterRemoveTest = (str) => {
    let obj = {
        rule: "originalFooterRemove_test",
        result: null,
        description: []
    }
    if (str.indexOf("<nav class=\"ac-gf-directory with-5-columns\" aria-label =\"\" role=\"navigation\">") !== -1) {
        obj.result = 'Failed';
        obj.description.push('Directory nav still can be found in code');
    } else {
        obj.result = 'Pass';
        obj.description.push('Directory nav is removed');
    }
    return obj;
}
//9
let hreflangRemoveTest = (str) => {
    let obj = {
        rule: "hreflangRemove_test",
        result: null,
        description: []
    }
    if (str.indexOf('<link rel=\"alternate\"') !== -1) {
        obj.result = 'Failed';
        obj.description.push('Hreflang still can be found in code');
    } else {
        obj.result = 'Pass';
        obj.description.push('Hreflang CSSs are removed');
    }

    return obj;
}
//10
let localNaveCssTest = (str, node) => {
    let $ = cheerio.load(str);
    let links = $(node);
    let tag = 0;
    let tagError = 0;
    let obj = {
        rule: "localNaveCss_test",
        result: null,
        description: []
    };
    let hrefName = [];
    for (let i = 0; i < links.length; i++) {
        if (links[i]) {
            hrefName[i] = links[i].attribs.href;
            if (hrefName[i].indexOf('ac-localnav.built.css') !== -1) {
                if (hrefName[i].indexOf('aow') !== -1) {
                    obj.result = 'Pass';
                    obj.description.push("link rel = " + hrefName[i]);
                    tag++;
                    break;
                }

            }
        } else {
            obj.result = 'Failed';
            obj.description.push('Exception message: Failed, no rel attribute');
            tagError++;
        }
    }
    if (tag === 0 && tagError === 0) {
        obj.result = "Failed";
        obj.description.push("Localnav has aow in its path or there is no rel about localnav");
    }
    return obj;
}

//11 font 待定
let fontTest = (str, node) => {
    let obj = {
        rule: "font_test",
        result: null,
        description: []
    };
    let $ = cheerio.load(str);
    let ps = $(node);
}

// 12
let buyStripBuiltCssRemoveTest = (str, node) => {
    let obj = {
        rule: "buyStripBuiltCssRemoveTest",
        result: null,
        description: []
    }
    let $ = cheerio.load(str);
    let links = $(node);
    let tag = 0;
    let tagError = 0;
    if (links) {
        for (let i = 0; i < links.length; i++) {
            let href = links[i].attribs.href;
            if (href.indexOf('buystrip.built.css') !== -1) {
                obj.result = "Failed";
                obj.description.push("Buystrip.built.css appears");
                tag++;
            }
        }
    } else {
        obj.result = "Failed";
        obj.description.push("Exception message: Did not find any link or no href attribute appears");
        tagError++;
    }
    if (tag === 0 && tagError === 0) {
        obj.result = 'Pass';
        obj.description.push('Buystrip.built.css is removed');
    }
    return obj;
}

//13
let wssFontCssRemoveTest = (str, node) => {
    let obj = {
        rule: "wssFontCssRemove_test",
        result: null,
        description: []
    }
    let $ = cheerio.load(str);
    let links = $(node);
    let tag = 0;
    let tagError = 0;
    if (links) {
        for (let i = 0; i < links.length; i++) {
            let href = links[i].attribs.href;
            if (href.indexOf('/wss/fonts?family=SF+Pro+SC') !== -1) {
                obj.result = 'Failed';
                obj.description.push('Wss Font appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push('Exception message: Did not find any link or no href attribute appears');
        tagError++;
    }
    if (tag === 0 && tagError === 0) {
        obj.result = 'Pass';
        obj.description.push('Wss Font is removed');
    }
    return obj;
}

//14
let sfproCssRemoveTest = (str, node) => {
    let obj = {
        rule: "sfproCssRemove_test",
        result: null,
        description: []
    }
    let $ = cheerio.load(str);
    let links = $(node);
    let tag = 0;
    let tagError = 0;
    if (links) {
        for (let i = 0; i < links.length; i++) {
            let href = links[i].attribs.href;
            if (href.indexOf('sfpro-cn.css') !== -1) {
                obj.result = 'Failed';
                obj.description.push('Sfpro-cn.css appears');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push('Exception message: Did not find any link or no href attribute appears');
        tagError++;
    }
    if (tag === 0 && tagError === 0) {
        obj.result = 'Pass';
        obj.description.push('Sfpro-cn.css is removed');
    }
    return obj;
}

//15
let ifIeRemoveTest = (str) => {
    let obj = {
        rule: "ifIeRemove_test",
        result: null,
        description: []
    }
    if (str.indexOf('<!--[if IE]>') !== -1) {
        obj.result = 'Failed';
        obj.description.push("&lt;!--[if IE]&gt; still can be found in code");
    } else {
        obj.result = 'Pass';
        obj.description.push('&lt;!--[if IE]&gt; is removed');
    }
    return obj;
}

//16
let fontIncRemoveTest = (str) => {
    let obj = {
        rule: "fontIncRemove_test",
        result: null,
        description: []
    }
    if (str.indexOf('font.inc') !== -1) {
        obj.result = 'Failed';
        obj.description.push("Font.inc still can be found in code");
    } else {
        obj.result = 'Pass';
        obj.description.push('Font.inc is removed');
    }
    return obj;
}

//17
let fontCssRemoveTest = (str, node, url) => {
    let obj = {
        rule: "fontCssRemove_test",
        result: null,
        description: []
    };
    let $ = cheerio.load(str);
    let links = $(node);
    let tag = 0;
    let tagError = 0;
    url = util.urlNormalize(url);
    let trimedUrl = url.split('.com')[1];
    if (trimedUrl === "/cn/iphone/compare/aow/" || trimedUrl === "/cn/ipad-mini-4/aow/"
        || trimedUrl === "/cn/iphone-x/aow/" || trimedUrl === "/cn/ipad-pro/aow/" || trimedUrl === '/cn/apple-watch-edition/aow/') {
        obj.result = 'Pass';
        obj.description.push('This is a special link, do not follow this rule');
        return obj;
    }
    if (links) {
        for (let i = 0; i < links.length; i++) {
            let href = links[i].attribs.href;
            if (href.indexOf('/font.css') !== -1 && href.indexOf('/cn/global/aow/styles/') === -1) {
                obj.result = 'Failed';
                obj.description.push('Font CSS appears and there is no /aow/ in its path');
                tag++;
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push('Exception message: Did not find any link or no href attribute appears');
        tagError++;
    }
    if (tag === 0 && tagError === 0) {
        obj.result = 'Pass';
        obj.description.push('Font CSS under /cn/PRODUCT_NAME/styles/ is removed Or Font CSS has /aow/ in its Path');
    }
    return obj;

}

// check how many times a text appears
let count = (text, sub) => {
    let indexStart = 0;
    let subStrLength = sub.split('').length;
    let count = 0;
    if (true) {
        let tm = text.indexOf(sub, indexStart);
        if (tm > 0) {
            count++;
            indexStart = tm + subStrLength;
        } else {
            return;
        }
    }
    return count;
}
//18
let socialShareImageDisplayOnceTest = (str, nodeObj) => {
    let obj = {
        rule: "socialShareImageDisplayOnce_test",
        result: null,
        description: []
    }
    let imageCodeCount = count(str, '<div style=\"display:none;\">');
    let $ = cheerio.load(str);
    if (imageCodeCount === 1) {
        let html1 = $(nodeObj.div, nodeObj.body).html();
        let src = $(nodeObj.img, html1)[0].attribs.src;
        if (src.indexOf('og_wechat.png') !== -1 && src.indexOf('aow') !== -1) {
            obj.result = 'Pass';
            obj.description.push("socialShareImage code appears once and src is " + src);
        } else {
            obj.result = 'Failed';
            obj.description.push('SocialShareImage code is incorrect ' + src);
        }
    } else if (imageCodeCount > 1) {
        obj.result = 'Failed';
        obj.description.push('SocialShareImage code appears more than once');
    } else {
        obj.result = 'Failed';
        obj.description.push('SocialShareImage code was not found');
    }
    return obj;
}

//19
let metaTagsLinkTest = (str, node) => {
    let obj = {
        rule: 'metaTagsLink_test',
        result: null,
        description: []
    }
    let $ = cheerio.load(str);
    let tag = 0;
    let metas = $(node);
    if (!metas) {
        obj.result = 'Failed';
        obj.description.push('Exception message: Did not find any meta tags');
        return obj;
    }
    for (let i = 0; i < metas.length; i++) {
        let metaProperty = metas[i].attribs.property;
        if (metaProperty) {
            if (metaProperty === 'og:url') {
                let content = metas[i].attribs.content;
                ;
                if (content.indexOf('/aow') !== -1) {
                    obj.result = 'Pass';
                    obj.description.push("Meta og:url include aow, the content is: " + content);
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Meta og:url not include aow, the content is: ' + content);
                }
                tag++;
            }
        }
    }
    if (tag === 0) {
        obj.result = 'Failed';
        obj.description.push('No og:url appears in meta or no proprety appears in meta tag');
    }
    return obj;
}

//20
let allImageLinkStartWithCnAowAddedTest = (str, nodeObj) => {
    let obj = {
        rule: 'allImageLinkStartWithCnAowAdded_test',
        result: null,
        description: []
    }
    let $ = cheerio.load(str);
    let tag = 0;
    let tagError = 0;
    let imgs = $(nodeObj.img);
    if (imgs) {
        for (let i = 0; i < imgs.length; i++) {
            let src = imgs[i].attribs.src;
            if (src && src in conf.mowUrl) {
                if (src.indexOf('aow') !== -1) {
                    obj.result = 'Pass';
                    obj.description.push("Aow appears in image links which contains /cn/PRODUCT_NAME/, the css url is " + src);
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Aow not appears in image links which contains /cn/PRODUCT_NAME/,the css url is ' + src);
                }
                tag++;
            }

        }
    } else {
        obj.result = 'Failed';
        obj.description.push('Exception message: Check point 1(source code image url),did not find any link or no href attribute appears');
        tagError++;
    }
    if (tag === 0 && tagError === 0) {
        obj.result = 'Pass';
        obj.description.push('No image links contains /cn/ do not need check aow');
    }
    let tagCn = 0;
    let tag2 = 0;
    let tag2Error = 0;
    let links = $(nodeObj.link);
    if (links) {
        for (let i = 0; i < links.length; i++) {
            if (links[i].attribs.rel.indexOf('stylesheet') !== -1) {
                let href = links[i].attribs.href;
                let regEx = href.split('.com')[1];
                if (regEx && regEx in conf.mowUrl) {
                    tagCn++;
                    if (href.indexOf('/aow/') === -1) {
                        obj.result = 'Failed';
                        obj.description.push('Aow not appears in image links which start with /cn/productName(in testing scope), the css url is' + href + "found in Css" + href);
                        tag2++;
                    }
                }
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push('Exception message: Check point 2(url in css),Did not find the tag link or no the attribute');
        tag2Error++;
    }
    if (tagCn === 0 && tag2Error === 0) {
        obj.result = 'Pass';
        obj.description.push('No image links start with /cn/productName(in testing scope)');
    } else if (tag2 === 0 && tag2Error === 0) {
        obj.result = 'Pass';
        obj.description.push('Aow appears in image links which start with /cn/productName(in testing scope)');
    }
    return obj;

}

//21
let canonicalKeepTheSameTest = (str, tempStr, node, url) => {
    let obj = {
        rule: 'canonicalKeepTheSame_test',
        result: null,
        description: []
    }
    let $ = cheerio.load(str);
    let compareUrl = url.replace('/aow', '');
    let href2 = '';
    let href = '';
    let links = $(node);
    if (links) {
        for (let i = 0; i < links.length; i++) {
            let rel = links[i].attribs.rel;
            if (rel === "Canonical") {
                href = links[i];
                $ = cheerio.load(tempStr);
                let links2 = $(node);
                if (links2) {
                    for (let i = 0; i < links2.length; i++) {
                        let rel2 = links[i].attribs.rel;
                        if (rel2 === "Canonical") {
                            href2 = links2[i].attribs.href;
                        }
                    }
                } else {
                    obj.result = 'Failed';
                    obj.description.push('Exception message: Rel = Canonical element not find');
                }
            }
        }
        if (href === href2) {
            obj.result = 'Pass';
            obj.description.push('Link rel=Canonical keep the same as before');
        } else {
            obj.result = 'Failed';
            obj.description.push('Rel=Canonical not found or it not the same as before');
        }
    } else {
        obj.result = 'Failed';
        obj.description.push('Exception message: Rel=Canonical element not find');
    }
    return obj;
}
//22
let aowPagelinkInAnotherPageAowAddedTest = (str, node,url) => {
    let obj = {
        rule: 'aowPagelinkInAnotherPageAowAdded_test',
        result: null,
        description: []
    };
    let $ = cheerio.load(str);
    let tag = 0;
    let tagError = 0;
    let tagnotest=0;
    let hrefs = $(node);
    let hrefName =[];
    let tempUrl =[];
    let aowUrl = [];
    let noAowUrl = [];
    let prefix = URL.parse(url).protocol + URL.parse(url).host;
    let hName = [];
    if (hrefs) {
        for (let i = 0; i < hrefs.length; i++) {
            hrefName[i] = hrefs[i].attribs.href;
            if (hrefName[i]) {
                if (URL.parse(hrefName[i]).protocol) {
                    hName[i] = hrefName[i];
                } else {
                    if (hrefName[i].split('')[0] !== '#') {
                        hName[i] = URL.parse(url).protocol + '//' + URL.parse(url).host + hrefName[i];
                    } else {
                        hName[i] = url + hrefName[i];

                    }

                }
                if(URL.parse(hrefName[i]).protocol){
                    tempUrl[i] = URL.parse(hrefName[i]).pathname;

                }else{
                    tempUrl[i] = hrefName[i];
                }

                if(tempUrl[i].indexOf('/aow/') !==-1){
                    aowUrl[i] = tempUrl[i].replace('aow/','');
                    if(aowUrl[i] && conf.mowUrl.contains(aowUrl[i])){
                        if(hrefName[i].indexOf('/aow/') !==-1){
                            obj.description.push({status: 'Pass',
                                                    href: hName[i]
                                                });
                            tagnotest ++;
                        }else{
                            obj.description.push({status: 'Failed',
                                                    href: hName[i]
                            });
                            tag ++;
                        }
                    }else{
                        obj.description.push({status: 'NO-Tested',
                                                href: hName[i]
                        });
                    }
                }else{
                    noAowUrl[i] = tempUrl[i];
                    if(conf.mowUrl.contains(noAowUrl[i])){
                        obj.description.push({status: 'Failed',
                                                href: hName[i]
                        });
                        tag++;
                    }else{
                        obj.description.push({status: 'NO-Tested',
                                                href: hName[i]
                        });
                    }
                }
            }
        }
    } else {
        obj.result = 'Failed';
        obj.description.push('Exception message: Elements not found');
        tagError++;
    }
    if(tag !== 0){
        obj.result = 'Failed';
    }
    if(tagnotest === hrefName.length){
        obj.description.unshift("Please check those non-tested URLs manually!");
        obj.result = 'NON-Tested';
    }
    if (tag === 0 && tagError === 0 && tagnotest === 0) {
        obj.result = 'Pass';
        obj.description.push('Aow Page link in tested Page added /aow/ or no aowPagelink appears in the tested page');
    }
    return obj;
}

//huoqu status code
let getSc = (url,auth) => {
    return new Promise((resolve, reject) => {
        request(url,(err,response,body) => {
            if(!err){
                resolve(response.statusCode);
            }else{
                reject(err);
            }
        },auth)
    });


};
//23
let returnStatusCodeTest = async (str, nodeObj, url, auth) => {
    let obj = {
        rule: 'returnStatusCode_test',
        result: null,
        description: []
    };
    let $ = cheerio.load(str);
    let tag = 0;
    let tag2 = 0;
    let hr = $(nodeObj.a);
    let hn = [];
    if (!hr) {
        obj.result = 'Failed';
        obj.description.push('Exception message: Elements not found');
        return obj;
    }
    let hrefName = [];
    for (let i = 0; i < hr.length; i++) {
        tag2 = 0;
        hrefName[i] = hr[i].attribs.href;
    }
    for (let j = 0; j < hrefName.length; j++) {
        if (URL.parse(hrefName[j]).protocol) {
            hn.push(hrefName[j]);
        } else {
            if (hrefName[j].split('')[0] !== '#') {
                hn.push(URL.parse(url).protocol + '//' + URL.parse(url).host + hrefName[j]);
            } else {
               hn.push(url + hrefName[j]);

            }

        }
    }
    for (let i = 0; i < hn.length; i++) {
        obj.result = 'Pass';
        console.log(hn[i]);
        if (hn[i].indexOf('mp4') !== -1) {
            obj.description[i] = {
                'site': hn[i],
                'status code': 'Please check this link manually'
            };
        }else{
            obj.description[i] = {
                'site': hn[i],
                'status code': hn[i].indexOf('itunes.apple.com') !== -1 ? 'Skip' : await getSc(hn[i],auth)

            };
        }
        tag++;
    }
    if (tag === 0) {
        obj.description = 'There is no href link in this page';
    }
    return obj;
}
exports.compare = compare;


