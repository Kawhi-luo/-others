/**
 * Created by edel.ma on 7/21/17.
 */

const font = require('../service/font');

// font.init(() => {
//     console.log(font.check('阿飞镂空设计的就快过完了'));
// });

console.log(font.getAvailableFontType());